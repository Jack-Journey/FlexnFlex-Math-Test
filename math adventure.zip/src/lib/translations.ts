export type Language = "en" | "de";

export const translations = {
  en: {
    // Character Selection
    chooseCharacter: "Choose Your Character",
    pickCharacterSubtext: "Pick a character to help you solve problems",
    floDescription: "Loves addition and subtraction!",
    flexDescription: "Expert at all math operations!",
    
    // Object Selection
    chooseObject: "Choose Your Object",
    chooseObjectSubtext: "What would you like to count today?",
    apples: "Apples",
    stars: "Stars",
    hearts: "Hearts",
    balls: "Balls",
    
    // Operation Selection
    chooseOperation: "Choose Operation",
    chooseOperationSubtext: "What type of math would you like to practice?",
    addition: "Addition",
    subtraction: "Subtraction",
    multiplication: "Multiplication",
    division: "Division",
    additionDesc: "Add numbers together",
    subtractionDesc: "Take away numbers",
    multiplicationDesc: "Multiply numbers",
    divisionDesc: "Divide numbers evenly",
    
    // Range Selection
    chooseRange: "Choose Number Range",
    chooseRangeSubtext: "Select the difficulty level",
    easy: "Easy",
    medium: "Medium",
    hard: "Hard",
    expert: "Expert",
    easyDesc: "Perfect for beginners",
    mediumDesc: "Great for practicing",
    hardDesc: "Ready for a challenge",
    expertDesc: "For math masters!",
    
    // Game Screen
    question: "Question",
    of: "of",
    score: "Score",
    solve: "Solve:",
    submit: "Submit",
    next: "Next",
    exit: "Exit",
    enterAnswer: "Enter your answer",
    correctFeedback: "🎉 Awesome! Get ready for the next one...",
    wrongFeedback: "Oops! Try again!",
    
    // Results Screen
    gameOver: "Game Over!",
    characterSays: "says:",
    yourScore: "Your Score",
    outOf: "out of",
    stars: "Stars",
    playAgain: "Play Again",
    home: "Home",
    perfectScore: "Perfect Score! You're a Math Champion! 🏆",
    excellentWork: "Excellent Work! You're amazing! 🌟",
    greatJob: "Great Job! Keep practicing! 👏",
    goodEffort: "Good Effort! You're improving! 💪",
    keepPracticing: "Keep Practicing! You'll get better! 🎯",
    percentCorrect: "You got {percent}% correct!",
    
    // Common
    back: "Back",
  },
  de: {
    // Character Selection
    chooseCharacter: "Wähle deinen Charakter",
    pickCharacterSubtext: "Wähle einen Charakter, der dir beim Lösen von Aufgaben hilft",
    floDescription: "Liebt Addition und Subtraktion!",
    flexDescription: "Experte für alle Rechenarten!",
    
    // Object Selection
    chooseObject: "Wähle dein Objekt",
    chooseObjectSubtext: "Was möchtest du heute zählen?",
    apples: "Äpfel",
    stars: "Sterne",
    hearts: "Herzen",
    balls: "Bälle",
    
    // Operation Selection
    chooseOperation: "Wähle Rechenart",
    chooseOperationSubtext: "Welche Art von Mathematik möchtest du üben?",
    addition: "Addition",
    subtraction: "Subtraktion",
    multiplication: "Multiplikation",
    division: "Division",
    additionDesc: "Zahlen zusammenzählen",
    subtractionDesc: "Zahlen abziehen",
    multiplicationDesc: "Zahlen multiplizieren",
    divisionDesc: "Zahlen gleichmäßig teilen",
    
    // Range Selection
    chooseRange: "Wähle Zahlenbereich",
    chooseRangeSubtext: "Wähle den Schwierigkeitsgrad",
    easy: "Einfach",
    medium: "Mittel",
    hard: "Schwer",
    expert: "Experte",
    easyDesc: "Perfekt für Anfänger",
    mediumDesc: "Gut für die Übung",
    hardDesc: "Bereit für einen Herausforderung",
    expertDesc: "Für Mathe-Meister!",
    
    // Game Screen
    question: "Frage",
    of: "von",
    score: "Punktzahl",
    solve: "Löse:",
    submit: "Absenden",
    next: "Weiter",
    exit: "Beenden",
    enterAnswer: "Gib deine Antwort ein",
    correctFeedback: "🎉 Super! Bereit für die nächste...",
    wrongFeedback: "Oops! Versuche es nochmal!",
    
    // Results Screen
    gameOver: "Spiel beendet!",
    characterSays: "sagt:",
    yourScore: "Deine Punktzahl",
    outOf: "von",
    stars: "Sterne",
    playAgain: "Nochmal spielen",
    home: "Startseite",
    perfectScore: "Perfekte Punktzahl! Du bist ein Mathe-Champion! 🏆",
    excellentWork: "Ausgezeichnete Arbeit! Du bist großartig! 🌟",
    greatJob: "Tolle Arbeit! Übe weiter! 👏",
    goodEffort: "Gute Leistung! Du wirst besser! 💪",
    keepPracticing: "Übe weiter! Du wirst es schaffen! 🎯",
    percentCorrect: "Du hast {percent}% richtig beantwortet!",
    
    // Common
    back: "Zurück",
  },
};

export function getTranslation(language: Language, key: keyof typeof translations.en): string {
  return translations[language][key];
}