/**
 * Character Library Type Definitions
 * Provides TypeScript types for Flo & Flex character library
 */

export type CharacterState = "smile" | "correct" | "wrong";

export type CharacterType = "flo" | "flex";

export interface CharacterProps {
  /** Current state of the character */
  state: CharacterState;
  /** Optional CSS classes for sizing and positioning */
  className?: string;
  /** Optional callback when state changes */
  onStateChange?: (state: CharacterState) => void;
}

export interface CharacterConfig {
  /** Whether to show shadow under the character */
  showShadow?: boolean;
  /** Size preset for the character */
  size?: "small" | "medium" | "large" | "xlarge";
  /** Duration in ms for auto-reset to smile state (0 = no auto-reset) */
  autoResetDuration?: number;
}

export interface ReactionOptions {
  /** Duration in ms before auto-resetting to smile state */
  duration?: number;
  /** Callback when reaction animation completes */
  onComplete?: () => void;
  /** Whether to play sound effects (for future enhancement) */
  playSound?: boolean;
}

export interface CharacterGroupConfig {
  /** Whether both characters should react together */
  synchronized?: boolean;
  /** Show character names below them */
  showNames?: boolean;
  /** Configuration for each character */
  config?: CharacterConfig;
}
