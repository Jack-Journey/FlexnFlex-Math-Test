# PWA Architecture Diagram

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER DEVICE                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌────────────────────────────────────────────────────────┐    │
│  │                    BROWSER / APP                        │    │
│  │                                                          │    │
│  │  ┌──────────────────────────────────────────────┐      │    │
│  │  │          React Application Layer              │      │    │
│  │  │  ┌────────────────────────────────────────┐  │      │    │
│  │  │  │         App.tsx (Main)                 │  │      │    │
│  │  │  │  • Game logic                          │  │      │    │
│  │  │  │  • Route management                    │  │      │    │
│  │  │  │  • State management                    │  │      │    │
│  │  │  └────────────────────────────────────────┘  │      │    │
│  │  │                                                │      │    │
│  │  │  ┌────────────────────────────────────────┐  │      │    │
│  │  │  │      PWA UI Components                 │  │      │    │
│  │  │  │  • OfflineIndicator.tsx                │  │      │    │
│  │  │  │  • UpdateNotification.tsx              │  │      │    │
│  │  │  │  • SyncStatus.tsx                      │  │      │    │
│  │  │  └────────────────────────────────────────┘  │      │    │
│  │  └──────────────────────────────────────────────┘      │    │
│  │                        ▲                                 │    │
│  │                        │ Events & Data                   │    │
│  │                        ▼                                 │    │
│  │  ┌──────────────────────────────────────────────┐      │    │
│  │  │         Service Worker Layer                  │      │    │
│  │  │  (service-worker.js - v1.0.0)                 │      │    │
│  │  │                                                │      │    │
│  │  │  ┌──────────────┐  ┌──────────────┐          │      │    │
│  │  │  │   Install    │  │   Activate   │          │      │    │
│  │  │  │   Handler    │  │   Handler    │          │      │    │
│  │  │  │              │  │              │          │      │    │
│  │  │  │ • Precache   │  │ • Clean old  │          │      │    │
│  │  │  │   app shell  │  │   caches     │          │      │    │
│  │  │  └──────────────┘  └──────────────┘          │      │    │
│  │  │                                                │      │    │
│  │  │  ┌──────────────────────────────────┐        │      │    │
│  │  │  │      Fetch Handler               │        │      │    │
│  │  │  │                                   │        │      │    │
│  │  │  │  Route request type:             │        │      │    │
│  │  │  │  • HTML → Network-first          │        │      │    │
│  │  │  │  • Images → Cache-first          │        │      │    │
│  │  │  │  • JS/CSS → Cache-first          │        │      │    │
│  │  │  │  • API → Network-first           │        │      │    │
│  │  │  └──────────────────────────────────┘        │      │    │
│  │  │                                                │      │    │
│  │  │  ┌──────────────────────────────────┐        │      │    │
│  │  │  │    Background Sync Handler       │        │      │    │
│  │  │  │  • Queue management              │        │      │    │
│  │  │  │  • Retry logic                   │        │      │    │
│  │  │  │  • Sync notifications            │        │      │    │
│  │  │  └──────────────────────────────────┘        │      │    │
│  │  └──────────────────────────────────────────────┘      │    │
│  │                        ▲                                 │    │
│  │                        │ Storage                         │    │
│  │                        ▼                                 │    │
│  │  ┌──────────────────────────────────────────────┐      │    │
│  │  │           Browser Storage Layer               │      │    │
│  │  │                                                │      │    │
│  │  │  ┌──────────────┐  ┌──────────────┐          │      │    │
│  │  │  │ Cache API    │  │  IndexedDB   │          │      │    │
│  │  │  │              │  │              │          │      │    │
│  │  │  │ • precache-  │  │ FloFlexMath  │          │      │    │
│  │  │  │   v1.0.0     │  │ DB           │          │      │    │
│  │  │  │ • runtime-   │  │              │          │      │    │
│  │  │  │   v1.0.0     │  │ • queued     │          │      │    │
│  │  │  │ • images-    │  │   Scores     │          │      │    │
│  │  │  │   v1.0.0     │  │   table      │          │      │    │
│  │  │  │ • api-       │  │              │          │      │    │
│  │  │  │   v1.0.0     │  │              │          │      │    │
│  │  │  └──────────────┘  └──────────────┘          │      │    │
│  │  └──────────────────────────────────────────────┘      │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
                              ▲
                              │ Network Requests
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                          NETWORK                                 │
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │   Netlify    │  │  Static CDN  │  │   API Server │          │
│  │   Hosting    │  │              │  │  (Future)    │          │
│  │              │  │  • JS bundles│  │              │          │
│  │  • index.html│  │  • CSS files │  │  • POST      │          │
│  │  • service-  │  │  • Images    │  │    /scores   │          │
│  │    worker.js │  │  • Fonts     │  │  • GET       │          │
│  │  • manifest  │  │              │  │    /user     │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
```

## 🔄 Data Flow Diagrams

### 1. First Visit (Online)

```
User navigates to app
         │
         ▼
┌─────────────────────┐
│  Browser requests   │
│  index.html         │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Server responds    │
│  with HTML          │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  HTML loads         │
│  register-sw.js     │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Service Worker     │
│  registers          │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  SW installs and    │
│  precaches files    │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  SW activates       │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  App loads from     │
│  network            │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Assets cached on   │
│  demand             │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  App ready for      │
│  offline use        │
└─────────────────────┘
```

### 2. Return Visit (Online, Cached)

```
User navigates to app
         │
         ▼
┌─────────────────────┐
│  SW intercepts      │
│  request            │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Check cache for    │
│  index.html         │
└─────────────────────┘
         │
         ▼
     Found? ──No──> Fetch from network
         │                    │
        Yes                   │
         │                    │
         ▼                    │
┌─────────────────────┐      │
│  Return from cache  │<─────┘
│  (instant)          │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  App loads from     │
│  cache < 1s         │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Network request    │
│  for updates (bg)   │
└─────────────────────┘
```

### 3. Offline Visit

```
User navigates to app (OFFLINE)
         │
         ▼
┌─────────────────────┐
│  SW intercepts      │
│  request            │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Try network        │
│  → FAILS            │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Fallback to cache  │
└─────────────────────┘
         │
         ▼
     Found? ──No──> Show offline.html
         │
        Yes
         │
         ▼
┌─────────────────────┐
│  Return from cache  │
│  (instant)          │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  App fully          │
│  functional offline │
└─────────────────────┘
```

### 4. Score Saving (Offline)

```
User completes game (OFFLINE)
         │
         ▼
┌─────────────────────┐
│  ResultsScreen      │
│  calls queueScore() │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  offlineSync.ts     │
│  opens IndexedDB    │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Create score       │
│  object with        │
│  timestamp          │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Store in           │
│  queuedScores       │
│  table              │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Register           │
│  background sync    │
│  (if supported)     │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Show "Score saved" │
│  notification       │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  SyncStatus badge   │
│  shows queued count │
└─────────────────────┘
```

### 5. Background Sync (Back Online)

```
Device goes online
         │
         ▼
┌─────────────────────┐
│  'online' event     │
│  fires              │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  OfflineIndicator   │
│  shows green banner │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Service Worker     │
│  'sync' event fires │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Open IndexedDB     │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Get all queued     │
│  scores             │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  For each score:    │
│  POST to API        │
└─────────────────────┘
         │
         ├─Success──> Remove from queue
         │                    │
         └─Fail────> Keep in queue, retry later
                              │
                              ▼
                    ┌─────────────────────┐
                    │  Notify React app   │
                    │  via postMessage    │
                    └─────────────────────┘
                              │
                              ▼
                    ┌─────────────────────┐
                    │  SyncStatus shows   │
                    │  success badge      │
                    └─────────────────────┘
```

### 6. App Update Flow

```
New version deployed
         │
         ▼
┌─────────────────────┐
│  User visits app    │
│  (old SW running)   │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Browser checks for │
│  SW updates         │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  New SW detected    │
│  (different VERSION)│
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  New SW installs    │
│  in background      │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  'updatefound'      │
│  event fires        │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  register-sw.js     │
│  detects update     │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Dispatch           │
│  'swUpdateAvailable'│
│  event              │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  UpdateNotification │
│  component shows    │
│  banner             │
└─────────────────────┘
         │
         ▼
User clicks "Update Now"
         │
         ▼
┌─────────────────────┐
│  Send SKIP_WAITING  │
│  message to new SW  │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  New SW activates   │
│  immediately        │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  controllerchange   │
│  event fires        │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  Page reloads       │
│  automatically      │
└─────────────────────┘
         │
         ▼
┌─────────────────────┐
│  App runs with      │
│  new version        │
└─────────────────────┘
```

## 📦 Cache Strategy Decision Tree

```
Incoming Request
      │
      ▼
  Request Type?
      │
      ├─────────> HTML Document
      │                │
      │                ▼
      │           Network First
      │                │
      │                ├─Success──> Cache & return
      │                │
      │                └─Fail────> Check cache
      │                                │
      │                                ├─Found──> Return cached
      │                                │
      │                                └─Not Found──> offline.html
      │
      ├─────────> Image
      │                │
      │                ▼
      │           Cache First
      │                │
      │                ├─Found──> Return cached
      │                │
      │                └─Not Found──> Fetch network
      │                                │
      │                                ├─Success──> Cache & return
      │                                │
      │                                └─Fail────> SVG placeholder
      │
      ├─────────> JS/CSS/Font
      │                │
      │                ▼
      │           Cache First
      │                │
      │                ├─Found──> Return cached
      │                │
      │                └─Not Found──> Fetch & cache
      │
      └─────────> API Call
                       │
                       ▼
                  Network First
                       │
                       ├─Success──> Cache (30 day expiry)
                       │
                       └─Fail────> Return cached (if available)
```

## 🎯 Component Interaction Map

```
┌─────────────────────────────────────────────────────────┐
│                        App.tsx                           │
│                                                          │
│  ┌────────────┐  ┌────────────┐  ┌────────────┐       │
│  │  Offline   │  │   Update   │  │    Sync    │       │
│  │ Indicator  │  │Notification│  │   Status   │       │
│  └────────────┘  └────────────┘  └────────────┘       │
│        ▲              ▲                ▲                │
│        │              │                │                │
│        │              │                │                │
│   ┌────┴──────────────┴────────────────┴────┐          │
│   │        Browser Event Listeners           │          │
│   │  • online/offline                        │          │
│   │  • swUpdateAvailable                     │          │
│   │  • service worker messages               │          │
│   └──────────────────────────────────────────┘          │
│                      ▲                                   │
│                      │                                   │
│   ┌──────────────────┴──────────────────────┐          │
│   │         register-sw.js                   │          │
│   │  • Registers service worker              │          │
│   │  • Detects updates                       │          │
│   │  • Dispatches events                     │          │
│   └──────────────────────────────────────────┘          │
│                      ▲                                   │
└──────────────────────┼───────────────────────────────────┘
                       │
┌──────────────────────┼───────────────────────────────────┐
│                      │      Service Worker               │
│                      ▼                                   │
│   ┌──────────────────────────────────────────┐          │
│   │        service-worker.js                 │          │
│   │                                           │          │
│   │  ┌─────────────┐  ┌─────────────┐       │          │
│   │  │  Fetch      │  │  Background │       │          │
│   │  │  Handler    │  │    Sync     │       │          │
│   │  └─────────────┘  └─────────────┘       │          │
│   │         │                 │               │          │
│   │         ▼                 ▼               │          │
│   │  ┌─────────────┐  ┌─────────────┐       │          │
│   │  │ Cache API   │  │  IndexedDB  │       │          │
│   │  └─────────────┘  └─────────────┘       │          │
│   └──────────────────────────────────────────┘          │
└─────────────────────────────────────────────────────────┘
```

---

**This architecture ensures:**
- ⚡ Fast loading (cache-first for assets)
- 🔌 Offline functionality (service worker + cache)
- 💾 Data persistence (IndexedDB)
- 🔄 Background sync (when online)
- 🔔 Update notifications (version management)
