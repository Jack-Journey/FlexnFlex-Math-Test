# PWA Testing Checklist

Use this checklist to verify your PWA works correctly before and after deployment.

## 🔍 Pre-Deployment Testing (Local)

### Build & Preview
- [ ] `npm run build` completes without errors
- [ ] `npm run preview` serves the built app
- [ ] No console errors on page load
- [ ] All routes work correctly

### Service Worker
- [ ] Service worker registers successfully
- [ ] Console shows: `✅ Service Worker registered`
- [ ] DevTools → Application → Service Workers shows "activated and is running"
- [ ] Version displayed correctly in console: `[SW v1.0.0]`

### Caching
- [ ] DevTools → Application → Cache Storage shows all caches:
  - `flo-flex-math-precache-v1.0.0`
  - `flo-flex-math-runtime-v1.0.0`
  - `flo-flex-math-images-v1.0.0`
  - `flo-flex-math-api-v1.0.0`
- [ ] Precache contains:
  - `/`
  - `/index.html`
  - `/manifest.json`
  - `/offline.html`
  - Icons

### Offline Mode (Desktop)
- [ ] Visit app with network enabled
- [ ] Wait for service worker to activate
- [ ] DevTools → Network → Select "Offline"
- [ ] Refresh page → App loads from cache
- [ ] Navigate between screens → Works offline
- [ ] Complete a game → Score queued
- [ ] Check IndexedDB → Score saved in `queuedScores`

### Manifest
- [ ] DevTools → Application → Manifest shows:
  - Name: "Flo & Flex Math Game"
  - Icons: 192x192, 512x512
  - Display: standalone
  - Theme color: #9333ea
- [ ] No manifest errors in console

### Icons
- [ ] Both icons exist in `/public`:
  - `icon-192.png`
  - `icon-512.png`
- [ ] Icons display correctly in manifest panel

## 🌐 Post-Deployment Testing (Production)

### Basic Functionality
- [ ] App loads on deployed URL
- [ ] HTTPS enabled (lock icon in browser)
- [ ] All assets load without 404 errors
- [ ] Console shows no errors
- [ ] All game features work

### Service Worker (Production)
- [ ] Service worker registers on first visit
- [ ] Console shows registration success
- [ ] Service worker becomes active
- [ ] Caches are populated

### Offline Fallback Page
- [ ] With network disabled, visit new page
- [ ] See custom offline.html page
- [ ] Page has Flo & Flex branding
- [ ] "Try Again" button works when back online

### Progressive Enhancement
- [ ] App works in browsers without SW support
- [ ] Graceful degradation for older browsers
- [ ] No critical errors in unsupported browsers

## 📱 Mobile Testing

### Android (Chrome)

#### Installation
- [ ] Visit app in Chrome mobile
- [ ] See "Add to Home Screen" banner OR
- [ ] Menu → "Install app" option available
- [ ] Click install → App added to home screen
- [ ] Icon appears with correct image
- [ ] App name displays correctly

#### Standalone Mode
- [ ] Open installed app
- [ ] Runs in fullscreen (no browser chrome)
- [ ] Purple theme color visible in status bar
- [ ] Splash screen shows on launch

#### Offline (Android)
- [ ] Enable Airplane Mode
- [ ] Open installed app
- [ ] App loads and works completely offline
- [ ] Play a game → Score saved
- [ ] Disable Airplane Mode
- [ ] App shows "Back online" notification
- [ ] Score syncs automatically
- [ ] Sync status indicator appears

### iOS (Safari)

#### Installation
- [ ] Visit app in Safari
- [ ] Tap Share button (square with arrow)
- [ ] Scroll to "Add to Home Screen"
- [ ] Tap → Icon added to home screen
- [ ] Icon shows correctly

#### Standalone Mode
- [ ] Open installed app
- [ ] Runs without Safari UI
- [ ] Status bar colored correctly
- [ ] Navigation works

#### Offline (iOS)
- [ ] Enable Airplane Mode
- [ ] Open app from home screen
- [ ] App works offline
- [ ] Complete a game
- [ ] Disable Airplane Mode
- [ ] Check if score syncs (limited on iOS)

> **Note:** iOS has limited service worker support. Background sync may not work.

## 🔄 Update Testing

### Trigger Update
- [ ] Increment VERSION in service-worker.js
- [ ] Deploy new version
- [ ] Keep old version open in browser
- [ ] Wait up to 1 hour OR
- [ ] Force update check in DevTools

### Update Flow
- [ ] Update notification appears
- [ ] Banner shows "New version available"
- [ ] Click "Update Now"
- [ ] App refreshes automatically
- [ ] New version loads
- [ ] Old cache cleared
- [ ] New cache created

### Update Dismissal
- [ ] Click "Later" on update notification
- [ ] Banner dismisses
- [ ] Can still use old version
- [ ] Update available on next visit

## 💾 Background Sync Testing

### Queue Scores Offline
- [ ] Go offline (Airplane Mode)
- [ ] Play and complete a game
- [ ] See score saved confirmation
- [ ] Check DevTools → Application → IndexedDB
- [ ] Verify score in `queuedScores` table
- [ ] Score has all fields: character, score, timestamp, etc.

### Sync When Online
- [ ] Go back online
- [ ] Service worker triggers sync automatically
- [ ] See "Scores synced successfully" notification
- [ ] Check IndexedDB → `queuedScores` empty
- [ ] Console shows sync success

### Multiple Scores
- [ ] Queue 3+ scores while offline
- [ ] Go online
- [ ] All scores sync
- [ ] Sync status shows count
- [ ] All scores removed from queue

## 🎨 UI Component Testing

### OfflineIndicator
- [ ] Go offline → Yellow banner appears
- [ ] Banner shows "You're offline" message
- [ ] Go online → Green banner appears
- [ ] Banner shows "Back online" message
- [ ] Banner auto-hides after 3 seconds

### UpdateNotification
- [ ] New version deployed
- [ ] Notification slides up from bottom
- [ ] Shows update message
- [ ] "Update Now" button works
- [ ] "Later" button dismisses
- [ ] "X" button dismisses

### SyncStatus
- [ ] Queue score offline
- [ ] See badge: "1 score queued"
- [ ] Go online
- [ ] Badge shows "Syncing..."
- [ ] After sync: "Scores synced successfully"
- [ ] Badge disappears after sync

## ⚡ Performance Testing

### Lighthouse Audit
- [ ] DevTools → Lighthouse
- [ ] Select "Progressive Web App"
- [ ] Generate report
- [ ] PWA score: 90+ ✅
- [ ] Performance score: 90+ ✅
- [ ] Check specific PWA criteria:
  - [ ] Fast load times
  - [ ] Works offline
  - [ ] Page load fast on 3G
  - [ ] Installable
  - [ ] Uses HTTPS
  - [ ] Redirects HTTP to HTTPS
  - [ ] Has viewport meta tag
  - [ ] Service worker registered

### Load Times
- [ ] First visit (network): < 3 seconds
- [ ] Cached visit: < 1 second
- [ ] Offline load: Instant
- [ ] Time to Interactive: < 3 seconds

### Cache Performance
- [ ] DevTools → Network → Disable cache OFF
- [ ] Refresh page
- [ ] Most assets from Service Worker
- [ ] Images load from cache
- [ ] JS/CSS from cache

## 🔒 Security Testing

### HTTPS
- [ ] Site uses HTTPS
- [ ] No mixed content warnings
- [ ] Service worker only works on HTTPS
- [ ] Manifest served over HTTPS

### Headers
- [ ] Service worker has correct headers:
  - `Cache-Control: max-age=0`
  - `Service-Worker-Allowed: /`
- [ ] Manifest has correct content-type
- [ ] No security warnings in console

## 🌍 Browser Compatibility

Test on multiple browsers:

### Desktop
- [ ] Chrome (latest)
- [ ] Edge (latest)
- [ ] Firefox (latest)
- [ ] Safari (latest if Mac)
- [ ] Opera (optional)

### Mobile
- [ ] Chrome Android (latest)
- [ ] Safari iOS (latest)
- [ ] Samsung Internet (optional)
- [ ] Firefox Mobile (optional)

## 📊 Feature Matrix

| Feature | Chrome Desktop | Chrome Android | Safari iOS | Firefox | Edge |
|---------|---------------|----------------|------------|---------|------|
| Service Worker | ✅ | ✅ | ⚠️ Limited | ✅ | ✅ |
| Offline Mode | ✅ | ✅ | ⚠️ Limited | ✅ | ✅ |
| Install | ✅ | ✅ | ✅ Manual | ✅ | ✅ |
| Background Sync | ✅ | ✅ | ❌ | ❌ | ✅ |
| Push Notifications | ✅ | ✅ | ❌ | ✅ | ✅ |
| Standalone Mode | ✅ | ✅ | ✅ | ✅ | ✅ |

✅ = Fully supported  
⚠️ = Partially supported  
❌ = Not supported

## 🐛 Common Issues to Check

### Service Worker Not Registering
- [ ] Check HTTPS
- [ ] Check console for errors
- [ ] Verify /service-worker.js exists
- [ ] Clear cache and hard refresh
- [ ] Check scope configuration

### App Not Installing
- [ ] Manifest valid (no errors)
- [ ] Icons exist and load
- [ ] Service worker registered
- [ ] HTTPS enabled
- [ ] Visited site multiple times (engagement requirement)

### Offline Not Working
- [ ] Service worker activated
- [ ] Caches populated
- [ ] Visit site online first
- [ ] Wait for caching to complete
- [ ] Test in installed app, not browser

### Scores Not Syncing
- [ ] IndexedDB accessible
- [ ] Browser supports Background Sync API
- [ ] Service worker receiving sync event
- [ ] Check console for sync errors
- [ ] Online when trying to sync

### Update Not Showing
- [ ] VERSION actually changed
- [ ] Wait 24 hours for browser check
- [ ] Force update in DevTools
- [ ] Close all tabs and reopen
- [ ] Clear service worker cache

## ✅ Sign-Off Checklist

Before going live, ensure:

- [ ] All local tests pass
- [ ] All deployment tests pass
- [ ] All mobile tests pass (Android & iOS)
- [ ] Update mechanism works
- [ ] Offline mode works
- [ ] Background sync works (where supported)
- [ ] Lighthouse PWA score 90+
- [ ] No console errors
- [ ] Icons display correctly
- [ ] App installs on all platforms
- [ ] Performance meets targets
- [ ] Security headers correct
- [ ] All browsers tested
- [ ] Documentation updated
- [ ] Team trained on PWA features

## 📝 Testing Log Template

```
Date: ___________
Tester: ___________
Version: ___________
Environment: ___________ (Local/Staging/Production)

Desktop Browser: ___________ (Chrome/Firefox/Safari/Edge)
Mobile Device: ___________ (iPhone/Android)
OS Version: ___________

Tests Passed: ___ / ___
Issues Found: ___________
Severity: ___________ (Critical/High/Medium/Low)
Notes: ___________

Sign-off: ___________ ✅/❌
```

---

**Complete this checklist before each release!**
