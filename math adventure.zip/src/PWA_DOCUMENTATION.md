# Progressive Web App (PWA) Documentation

## 🚀 Overview

Flo & Flex Math Game is a production-ready Progressive Web App with robust offline functionality, background sync, and automatic updates.

## 📋 Features

### ✅ Offline Support
- **Cache-first strategy** for static assets (JS, CSS, images, fonts)
- **Network-first strategy** for API calls with cache fallback
- **App shell caching** for instant loading
- **Dedicated offline page** when network is unavailable
- **Runtime caching** for dynamic content

### 🔄 Background Sync
- Game scores are queued when offline
- Automatic sync when connection is restored
- IndexedDB storage for queued data
- User notifications on successful sync

### 🔔 Update Notifications
- Automatic detection of new app versions
- User-friendly update prompts
- Manual update triggering
- Seamless update experience

### 💾 Caching Strategy

#### Precache (v1.0.0)
- `/` (root)
- `/index.html`
- `/manifest.json`
- `/offline.html`
- `/icon-192.png`
- `/icon-512.png`

#### Runtime Caches
1. **Static Assets Cache** - JS, CSS, fonts (unlimited duration)
2. **Images Cache** - Up to 60 images, 90-day expiration
3. **API Cache** - Up to 30 responses, 30-day expiration
4. **Runtime Cache** - Up to 50 items, general caching

### 📊 Cache Management
- **Automatic versioning** - Caches tied to service worker version
- **Size limits** - Prevents unlimited cache growth
- **Expiration policies** - Removes stale content
- **Cleanup on activation** - Removes old cache versions

## 🛠️ Technical Implementation

### Service Worker (`/public/service-worker.js`)

**Version:** v1.0.0

**Key Features:**
- Strategic caching patterns
- Cache size management
- Timestamp-based expiration
- Background sync support
- Update detection

**Cache Strategies:**

```javascript
// 1. API Requests - Network-first with cache fallback
if (url.pathname.startsWith('/api/')) {
  networkFirstWithCache(request, API_CACHE_NAME, 30 days);
}

// 2. Images - Cache-first with network fallback
if (isImage(request)) {
  cacheFirstWithNetwork(request, IMAGES_CACHE_NAME, 90 days);
}

// 3. Static Assets - Cache-first
if (isStaticAsset(request)) {
  cacheFirstWithNetwork(request, PRECACHE_NAME);
}

// 4. HTML - Network-first with offline fallback
if (isDocument(request)) {
  networkFirstWithOfflineFallback(request);
}
```

### Registration (`/public/register-sw.js`)

**Features:**
- Automatic service worker registration
- Update detection and notification
- Hourly update checks
- Visual update prompts
- Background sync registration

### Offline Sync (`/lib/offlineSync.ts`)

**IndexedDB Schema:**
```javascript
Database: FloFlexMathDB
Store: queuedScores
Fields: {
  id: autoIncrement,
  character: string,
  score: number,
  totalQuestions: number,
  operation: string,
  range: string,
  timestamp: number
}
```

**API:**
- `queueScore(scoreData)` - Queue score for sync
- `getQueuedScores()` - Get all queued scores
- `removeQueuedScore(id)` - Remove synced score
- `clearQueuedScores()` - Clear all queued scores
- `getQueuedScoresCount()` - Get count of queued scores
- `listenForSyncEvents(callback)` - Listen for sync events
- `isOnline()` - Check online status
- `waitForOnline()` - Wait for connection

## 🎨 UI Components

### OfflineIndicator (`/components/pwa/OfflineIndicator.tsx`)
Shows connection status with slide-down animation:
- Yellow banner when offline
- Green banner when back online
- Auto-hides after 3 seconds when online

### UpdateNotification (`/components/pwa/UpdateNotification.tsx`)
User-friendly update prompt:
- Slide-up animation
- "Update Now" and "Later" buttons
- Dismissible
- Automatic reload on update

## 📱 Manifest (`/public/manifest.json`)

**Configuration:**
- Name: "Flo & Flex Math Game"
- Display: Standalone (fullscreen app)
- Theme Color: #9333ea (purple)
- Icons: 192x192, 512x512
- Categories: Education, Games, Kids
- Shortcuts: Quick actions
- Screenshots: For app stores

## 🔧 Usage

### Installing the PWA

**Desktop (Chrome/Edge):**
1. Visit the app URL
2. Click install icon in address bar
3. Click "Install" in the prompt

**Mobile (iOS Safari):**
1. Open app in Safari
2. Tap Share button
3. Select "Add to Home Screen"

**Mobile (Android Chrome):**
1. Open app in Chrome
2. Tap "Add to Home Screen" banner
3. Or use menu → "Install app"

### Offline Usage

1. **First load** - App must be visited online first
2. **Offline access** - Works completely offline after installation
3. **Score saving** - Scores saved locally when offline
4. **Auto-sync** - Syncs when connection restored

### Updating the App

**Automatic:**
- App checks for updates every hour
- Shows notification when available
- User clicks "Update Now"

**Manual:**
- User can always refresh to check
- Service worker updates in background

## 🚀 Deployment

### Required Headers (Netlify)

```toml
# netlify.toml
[[headers]]
  for = "/service-worker.js"
  [headers.values]
    Cache-Control = "public, max-age=0, must-revalidate"
    Service-Worker-Allowed = "/"

[[headers]]
  for = "/manifest.json"
  [headers.values]
    Content-Type = "application/manifest+json"
```

### HTTPS Requirement
Service Workers require HTTPS. Netlify provides this automatically.

### Build Configuration

```bash
# Build command
npm run build

# Publish directory
build
```

## 📊 Performance Metrics

### Cache Sizes
- **Precache:** ~2-5 MB (app shell)
- **Runtime Cache:** ~5-10 MB (dynamic content)
- **Images Cache:** ~10-20 MB (60 images max)
- **API Cache:** ~1-2 MB (30 responses max)
- **Total:** Target under 50 MB

### Load Times
- **First visit:** Network dependent
- **Repeat visit:** < 1 second (cached)
- **Offline:** Instant (cached)

## 🔍 Debugging

### Chrome DevTools

**Application Tab:**
1. **Service Workers** - View registration, status
2. **Cache Storage** - Inspect cached files
3. **Clear Storage** - Reset everything

**Network Tab:**
- Filter by "Service Worker"
- See what's cached vs network

**Console:**
- Service worker logs prefixed with `[SW v1.0.0]`
- Sync events logged

### Testing Offline

**Chrome DevTools:**
1. Open DevTools (F12)
2. Network tab → Throttling → Offline
3. Refresh page

**Lighthouse:**
1. DevTools → Lighthouse
2. Check "Progressive Web App"
3. Generate report

## 🐛 Troubleshooting

### Service Worker Not Registering
- Check HTTPS (required)
- Check console for errors
- Clear cache and hard refresh (Ctrl+Shift+R)

### Offline Page Not Showing
- Ensure `/offline.html` is precached
- Check service worker is active
- Verify offline.html exists in build

### Updates Not Showing
- Increment VERSION in service-worker.js
- Wait up to 24 hours for browser check
- Or close all tabs and reopen

### Scores Not Syncing
- Check IndexedDB in DevTools → Application
- Verify Background Sync API support
- Check network connectivity

## 📈 Version History

### v1.0.0 (Current)
- ✅ Complete offline support
- ✅ Background sync for scores
- ✅ Automatic update notifications
- ✅ Strategic caching patterns
- ✅ Cache management and expiration
- ✅ Offline/online indicators
- ✅ Enhanced manifest

## 🔮 Future Enhancements

- [ ] Push notifications for achievements
- [ ] Periodic background sync
- [ ] Share API integration
- [ ] File system access for exports
- [ ] Badge API for score notifications
- [ ] Install prompt optimization
- [ ] Web Share Target API

## 📚 Resources

- [Service Worker API](https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API)
- [Background Sync API](https://developer.mozilla.org/en-US/docs/Web/API/Background_Sync_API)
- [Web App Manifest](https://developer.mozilla.org/en-US/docs/Web/Manifest)
- [PWA Best Practices](https://web.dev/pwa-checklist/)
- [Workbox (Advanced)](https://developers.google.com/web/tools/workbox)

## 📝 Notes

- Service worker updates require incrementing VERSION
- Cache names include version for automatic cleanup
- IndexedDB persists across sessions
- Background sync may not work on all browsers
- iOS Safari has limited PWA support
