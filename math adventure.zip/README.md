
  # math adventure

  This is a code bundle for math adventure. The original project is available at https://www.figma.com/design/3F9tSCsNFIVvbrGlDJgHDU/math-adventure.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  